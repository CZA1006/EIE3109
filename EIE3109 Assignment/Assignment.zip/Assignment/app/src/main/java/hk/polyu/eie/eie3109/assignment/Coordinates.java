package hk.polyu.eie.eie3109.assignment;


import android.graphics.Bitmap;

public class Coordinates {
    private int x = 100;//corner coor
    private int y = 0;
    private Bitmap bitmap;

    public Coordinates(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
    public void setX(int x) {
        this.x = x ;
    }
    public int getX() {//center coor
        return x ;
    }
    public void setY(int y) {
        this.y = y;
    }
    public int getY() {
        return y ;//+ bitmap.getHeight()/2;
    }

}